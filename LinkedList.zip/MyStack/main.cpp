#include <iostream>
#include <string>
#include <vector>
#include <iomanip>
#include <algorithm>
#include "MyDeque.cpp"
#include "LinkedList.cpp"
#include "Joseph.cpp"

using namespace std;

void testlq() {
	LinkedList<int> cq;
	cq.insert(0, 999);
	cq.insert(0, 1111);
	cq.insert(0, 22222);
	cq.insert(1, 32215);
	cq.pop_last();
	cq.remove(0);
}

void start_demonstration();

int main() {
	JosephList j;
	j.doJoseph(8,3);
}

