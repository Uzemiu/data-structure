#pragma once
#include "MyDeque.h"

template<class T>
struct Node {
	T ele;
	Node<T>* next;
	Node<T>* prev;
	Node();
	Node(T ele);
};

template<class T>
inline Node<T>::Node() {
	ele = T();
	next = 0;
	prev = 0;
}

template<class T>
inline Node<T>::Node(T ele) {
	this->ele = ele;
	next = 0;
	prev = 0;
}

template <class T>
class LinkedList : public MyDeque<T> {
public:
	LinkedList();
	~LinkedList();

	void push(T ele);
	T pop();
	T peek();

	void push_first(T ele);
	void push_last(T ele);
	T peek_first();
	T peek_last();
	T pop_first();
	T pop_last();
	void insert(int i, T ele);
	T remove(int i);

	size_t size();
	bool empty();
	void clear();

protected:
	Node<T>* head;
	size_t _size;

	void insert(int i, T ele, bool last);
	T remove(Node<T>* node);
};

