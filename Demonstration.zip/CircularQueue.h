
#include "MyQueue.h"

template<class T>
struct Node {
	T ele;
	Node<T>* next;
	Node();
	Node(T ele);
};

template<class T>
inline Node<T>::Node() {
	ele = T();
}

template<class T>
inline Node<T>::Node(T ele) {
	this->ele = ele;
}

template <class T>
class CircularQueue : public MyQueue<T> {
public:
	CircularQueue();
	~CircularQueue();

	void push(T ele);
	T pop();
	T peek();
	size_t size();
	bool empty();
	void clear();

private:
	// front = head->next
	Node<T>* head;
	Node<T>* rear;
	size_t _size;
};

