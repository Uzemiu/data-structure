#include "LinkedList.h"

template<class T>
LinkedList<T>::LinkedList() {
	_size = 0;
	head = nullptr;
}

template<class T>
LinkedList<T>::~LinkedList() {
	clear();
}

template<class T>
void LinkedList<T>::push(T ele) {
	push_first(ele);
}

template<class T>
T LinkedList<T>::pop() {
	return pop_last();
}

template<class T>
T LinkedList<T>::peek() {
	if (empty()) throw "Empty queue";
	return head->next->ele;
}

template<class T>
void LinkedList<T>::push_first(T ele) {
	insert(0, ele, false);
}

template<class T>
void LinkedList<T>::push_last(T ele) {
	insert(0, ele, true);
}

template<class T>
T LinkedList<T>::peek_first() {
	if (empty()) {
		throw "Empty list";
	}
	return head->ele;
}

template<class T>
T LinkedList<T>::peek_last() {
	if (empty()) {
		throw "Empty list";
	}
	return head->prev->ele;
}

template<class T>
T LinkedList<T>::pop_first() {
	if (empty()) {
		throw "Empty list";
	}
	return remove(0);
}

template<class T>
T LinkedList<T>::pop_last() {
	if (empty()) {
		throw "Empty list";
	}
	return remove(head->prev);
}

template<class T>
void LinkedList<T>::insert(int i, T ele) {
	insert(i, ele, false);
}

template<class T>
T LinkedList<T>::remove(int i) {
	if (empty()) {
		throw "Empty list";
	}
	Node<T>* node = head;
	for (int j = 0; j < i; j++) {
		node = node->next;
	}
	return remove(node);
}

template<class T>
size_t LinkedList<T>::size() {
	return _size;
}

template<class T>
bool LinkedList<T>::empty() {
	return _size == 0;
}

template<class T>
void LinkedList<T>::clear() {
	while (!empty()) remove(0);
	_size = 0;
}

template<class T>
void LinkedList<T>::insert(int i, T ele, bool last) {
	Node<T>* next = head;
	Node<T>* newN = new Node<T>(ele);
	if (next) {
		if (i > _size) {
			i = _size;
		}
		for (int j = 0; j < i; j++) {
			next = next->next;
		}
		Node<T>* prev = next->prev;
		newN->prev = prev;
		newN->next = next;
		prev->next = newN;
		next->prev = newN;

		if (!last && i == 0) {
			head = newN;
		}

	} else {
		head = newN;
		head->next = head;
		head->prev = head;
	}
	_size++;
}

template<class T>
T LinkedList<T>::remove(Node<T>* node) {
	Node<T>* prev = node->prev;
	node->prev->next = node->next;
	node->next->prev = node->prev;
	T ele = node->ele;
	if (node == head) {
		head = head->next;
	}
	delete node;
	_size--;
	if (_size == 0) {
		head = nullptr;
	}
	return ele;
}
