#include <iostream>
#include <string>
#include <vector>
#include <iomanip>
#include <algorithm>
#include "MyDeque.cpp"
#include "CircularQueue.cpp"

using namespace std;

void testmydeque() {
	MyDeque<int> q(5);
	for (int i = 0; i < 200; i += 2) {
		q.push_first(i);
		q.push_last(i + 1);
	}
	while (!q.empty()) {
		cout << q.pop_first() << endl;
	}
	cout << "--------------------------------" << endl;
	for (int i = 200; i <= 210; i++) {
		q.push(i);
	}
	while (!q.empty()) {
		cout << q.pop() << endl;
	}
}

void testlq() {
	CircularQueue<int> cq;
	for (int i = 0; i < 10; i++) {
		cq.push(i);
	}
	for (int i = 0; i < 5; i++) {
		cq.pop();
	}
	for (int i = 100; i < 110; i++) {
		cq.push(i);
	}
	while (!cq.empty()) {
		cout << cq.pop() << endl;
	}
	for (int i = 100; i < 110; i++) {
		cq.push(i);
	}
}

void start_demonstration();

int main() {
	start_demonstration();
	//testlq();
}

