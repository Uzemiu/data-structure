#include "CircularQueue.h"

template<class T>
CircularQueue<T>::CircularQueue() {
	this->head = new Node<T>();
	head->next = head;
	_size = 0;
	rear = nullptr;
}

template<class T>
CircularQueue<T>::~CircularQueue() {
	clear();
}

template<class T>
void CircularQueue<T>::push(T ele) {
	Node<T>* node = new Node<T>(ele);
	if (empty()) {
		head->next = node;
	} else {
		rear->next = node;
	}
	node->next = head;
	rear = node;
	_size++;
}

template<class T>
T CircularQueue<T>::pop() {
	if (empty()) throw "Empty queue";
	Node<T> *t = head->next;
	T res = t->ele;
	head->next = head->next->next;
	delete t;
	_size--;
	return res;
}

template<class T>
T CircularQueue<T>::peek() {
	if (empty()) throw "Empty queue";
	return head->next->ele;
}

template<class T>
size_t CircularQueue<T>::size() {
	return _size;
}

template<class T>
bool CircularQueue<T>::empty() {
	return _size == 0;
}

template<class T>
void CircularQueue<T>::clear() {
	while (!empty()) pop();
	_size = 0;
}
